import React from 'react';  
import logo from './logo.svg';  
import './App.css';  
import Layout  from './components/layout'  
import {  } from "module";
//import Login from "./Login";  
//import { HashRouter, Route, Switch } from 'react-router-dom';  
{/* <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.css">
<link rel="stylesheet" type="text/css" href="assets/css/animate.css">
<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="assets/css/all.css">
<link rel="stylesheet" type="text/css" href="assets/css/app-ltr.css"> */}
// import  "../bootstrap.min.css";
// import "../bootstrap-select.min.css";
// import "../bootstrap-datetimepicker.css";
// //import  "./assets/css/animate.css";

// import '~/assets/css/all.css';
// import "~/assets/css/app-ltr.css";



function App() {  
  return (  
     <div className="App">  
      <Layout/>   
      
     </div>  
  );  
}  
  
export default App; 